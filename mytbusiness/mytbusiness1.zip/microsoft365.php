<?php

require_once('includes/init.php');

 

//$smarty->assign('hotlinefooter','8901');

 

$smarty->display('microsoft365.tpl');

?>








